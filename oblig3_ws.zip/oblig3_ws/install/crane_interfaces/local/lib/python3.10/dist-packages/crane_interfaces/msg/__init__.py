from crane_interfaces.msg._motion_reference import MotionReference  # noqa: F401
