// generated from rosidl_generator_c/resource/idl.h.em
// with input from crane_interfaces:msg/MotionReference.idl
// generated code does not contain a copyright notice

#ifndef CRANE_INTERFACES__MSG__MOTION_REFERENCE_H_
#define CRANE_INTERFACES__MSG__MOTION_REFERENCE_H_

#include "crane_interfaces/msg/detail/motion_reference__struct.h"
#include "crane_interfaces/msg/detail/motion_reference__functions.h"
#include "crane_interfaces/msg/detail/motion_reference__type_support.h"

#endif  // CRANE_INTERFACES__MSG__MOTION_REFERENCE_H_
