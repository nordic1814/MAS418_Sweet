// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CRANE_INTERFACES__MSG__MOTION_REFERENCE_HPP_
#define CRANE_INTERFACES__MSG__MOTION_REFERENCE_HPP_

#include "crane_interfaces/msg/detail/motion_reference__struct.hpp"
#include "crane_interfaces/msg/detail/motion_reference__builder.hpp"
#include "crane_interfaces/msg/detail/motion_reference__traits.hpp"

#endif  // CRANE_INTERFACES__MSG__MOTION_REFERENCE_HPP_
