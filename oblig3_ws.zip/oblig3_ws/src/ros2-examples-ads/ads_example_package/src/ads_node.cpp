#include <iostream>
#include <string>
#include "AdsLib.h"
#include "AdsVariable.h"

#include <thread>
#include <chrono>
#include <functional>
#include <memory>
#include <cmath>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "sensor_msgs/msg/joint_state.hpp"














namespace craneads {

    struct AdsVariables
    {
        AdsVariables() = delete;

        explicit AdsVariables(AdsDevice& route)
            : activateMotion{route, "MAIN.bActivateMotion"}
            , automode{route, "MAIN.bAuto"}
            , manualmode{route, "MAIN.bManual"}
            , pistonPressure{route, "MAIN.fPrPist"}
            , rodPressure{route, "MAIN.fPrRod"}
            , boomAngle{route, "MAIN.fBoomAngle"}
            , boomAngleRef{route, "MAIN.fBoomAngleRef"}

        {
            // Do nothing.
        }

        AdsVariable<bool> activateMotion;
        AdsVariable<bool> automode;
        AdsVariable<bool> manualmode;
        AdsVariable<double> pistonPressure;
        AdsVariable<double> rodPressure;
        AdsVariable<double> boomAngle;
        AdsVariable<double> boomAngleRef;
    
    };














class AdsHandler
    {
    public:
        explicit AdsHandler(const AmsNetId remoteNetId, const std::string remoteIpV4)
            : remoteNetId_(remoteNetId)
            , remoteIpV4_(remoteIpV4)
            , route_{remoteIpV4_, remoteNetId_, AMSPORT_R0_PLC_TC3}
            , ads_(route_) { }

        AdsHandler() : AdsHandler({192, 168, 0, 10,  1, 1}, "192.168.0.10") { }


        void activateMotion()
        {
            ads_.activateMotion = true;
        }

        void deactivateMotion()
        {
            ads_.activateMotion = false;
        }
        
        void setAuto()
        {
            ads_.automode = true;
            ads_.manualmode = false;
        }
        
        void setManual()
        {
            ads_.manualmode = true;
            ads_.automode = false;
        }


        double getPistonPressure()
        {
            return ads_.pistonPressure;
        }

        double getRodPressure()
        {
            return ads_.rodPressure;
        }
        
        double getBoomAngle()
        {
            return ads_.boomAngle;
        }


        void setBoomAngleRef(double pos)
        {
            ads_.boomAngleRef = pos;
        }

        void printState()
        {
            const auto state = route_.GetState();
            std::cout << "ADS state: "
                      << std::dec << static_cast<uint16_t>(state.ads)
                      << " devState: "
                      << std::dec << static_cast<uint16_t>(state.device);
        }

        ~AdsHandler() { }

    private:
        const AmsNetId remoteNetId_;
        const std::string remoteIpV4_;
        AdsDevice route_;
        AdsVariables ads_;
    };

}
















double NotMain()
{

  //std::cout << "Example ROS2 ADS node starting up.." << std::endl;


  // Real lab PLC IP.
  const AmsNetId remoteNetId { 192, 168, 0, 10, 1, 1 };
  const std::string remoteIpV4 = "192.168.0.10";


  //std::cout << "  Create AdsHandler.. ";
  craneads::AdsHandler adsHandler(remoteNetId, remoteIpV4);
  //std::cout << "  OK" << std::endl;


  //adsHandler.setBoomAngleRef(0.6);
  adsHandler.setManual();
  //adsHandler.setAuto();
  adsHandler.activateMotion();



  double position = 1.0 * adsHandler.getBoomAngle();
  std::cout << "Pressure measurements from ADS (rod, piston): " << adsHandler.getRodPressure() <<" "<< adsHandler.getPistonPressure() << std::endl;


  return position;
}



















using namespace std::chrono_literals;

class MinimalPublisher : public rclcpp::Node
{
public:
  MinimalPublisher()
  : Node("crane_controll"), count_(0)
  {
    publisher_ = this->create_publisher<sensor_msgs::msg::JointState>("joint_states", 10); 
    timer_ = this->create_wall_timer(1ms, std::bind(&MinimalPublisher::timer_callback, this));
    

  }

private:
  void timer_callback()
  {
    double position = NotMain();
    //std::cout << "POSITION!!!! '%d'" << position<< std::endl;

    auto message = sensor_msgs::msg::JointState();				
    message.name = {"base_to_crane_boom"};					// CHANGE
    message.position = {position};
    message.velocity = {0.01}; 
    message.header.stamp = this->get_clock()->now();
    
    
    publisher_->publish(message);
    
    
  }
  rclcpp::TimerBase::SharedPtr timer_;
  
  
  rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr publisher_;	// CHANGe
  size_t count_;
};
















int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MinimalPublisher>());
  rclcpp::shutdown();
  return 0;
}






